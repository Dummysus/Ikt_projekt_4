const reklam_elements = []
const reklamok = ["aids", "biden", "milf", "penis", "porszivo", "bean", "urban", "beautystar", "csodakrem", "david", "faszpro", "games", "getrichquick", "india", "kinder", "keresztenypropaganda", "predator", "szerencsejatek", "virusscam", "faszpro", "bean"]


Array.prototype.forEach.call(document.getElementsByClassName("reklamfelso"), function(e) {
  reklam_elements.push(e)
});

Array.prototype.forEach.call(document.getElementsByClassName("reklamalso"), function(e) {
  reklam_elements.push(e)
});

setInterval(() => {
  for (let i = 0; i < reklam_elements.length; i++) {
    reklam_elements[i].src = `img/${reklamok[Math.floor(Math.random() * (reklamok.length - 1))]}.png`
  }
}, 7000)